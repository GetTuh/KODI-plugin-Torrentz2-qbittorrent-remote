from qbittorrent.client import Client
