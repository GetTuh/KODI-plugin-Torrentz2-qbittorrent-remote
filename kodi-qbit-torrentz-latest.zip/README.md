## Unofficial KODI plugin for scraping torrentz2.eu, getting magnet link and connecting to remote qbittorrent server

# Usage:
1. [Get and install the latest .zip](https://github.com/GetTuh/KODI-plugin-Torrentz2-qbittorrent-remote/raw/master/kodi-qbit-torrentz-latest.zip)

1. On server launch qbittorrent,  go to Tools->Options... , select Web UI tab and configure web user interface

1. Launch addon and use the qbittorrent setup to configure connection

# Functions
* Search torrentz2.eu for given query
* Adding torrents from torrentz2.eu 
* Deleting torrents with or without removing files from server
* Sequential download as default for watching movies/series while downloading
