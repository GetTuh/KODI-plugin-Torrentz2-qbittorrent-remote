from qbittorrent import *

qb = Client('http://192.168.0.101:8080')
qb.login('admin', 'q1w2e3')
